package com.example.powertrack.model;

public class Aparato {
    private String nombre;
    private String descripcion;
    private float umbral;
    private String estado;
    private float consumoActual;
    private TipoAparato tipoAparato;

    public Aparato() {
    }

    public Aparato(String nombre, String descripcion, float umbral, String estado, float consumoActual, TipoAparato tipoAparato) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.umbral = umbral;
        this.estado = estado;
        this.consumoActual = consumoActual;
        this.tipoAparato = tipoAparato;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public float getUmbral() {
        return umbral;
    }

    public void setUmbral(float umbral) {
        this.umbral = umbral;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public float getConsumoActual() {
        return consumoActual;
    }

    public void setConsumoActual(float consumoActual) {
        this.consumoActual = consumoActual;
    }

    public TipoAparato getTipoAparato() {
        return tipoAparato;
    }

    public void setTipoAparato(TipoAparato tipoAparato) {
        this.tipoAparato = tipoAparato;
    }

    @Override
    public String toString() {
        return this.nombre;
    }
}
