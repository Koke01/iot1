package com.example.powertrack.model;

import java.util.List;

public class Sensor {
    private String nombre;
    private String modelo;
    private float lecturaActual;
    private Ubicacion ubicacion;
    private String tipo;
    private String descripcion;
    private List<Registro> registros;  // Lista de registros

    public Sensor(String nombre, String modelo, float lecturaActual, Ubicacion ubicacion, String tipo, String descripcion, List<Registro> registros) {
        this.nombre = nombre;
        this.modelo = modelo;
        this.lecturaActual = lecturaActual;
        this.ubicacion = ubicacion;
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.registros = registros;  // Guardamos los registros
    }

    public List<Registro> getRegistros() {
        return registros;
    }

    public Registro obtenerUltimoRegistro() {
        if (registros != null && !registros.isEmpty()) {
            return registros.get(registros.size() - 1);  // Retorna el último registro
        }
        return null;  // Retorna null si no hay registros
    }

    // Otros métodos y getters/setters

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public float getLecturaActual() {
        return lecturaActual;
    }

    public void setLecturaActual(float lecturaActual) {
        this.lecturaActual = lecturaActual;
    }

    public Ubicacion getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(Ubicacion ubicacion) {
        this.ubicacion = ubicacion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + "\n" +
                "Modelo: " + modelo + "\n" +
                "Lectura Actual: " + lecturaActual + "\n" +
                "Tipo: " + tipo + "\n" +
                "Descripción: " + (descripcion != null ? descripcion : "No asignada") + "\n" +
                "Ubicación: " + (ubicacion != null ? ubicacion.toString() : "No asignada");
    }
}
