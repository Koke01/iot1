package com.example.powertrack.model;

import java.util.Date;

public class Registro {
    private float valor;
    private Date fechaHora;  // Guardamos la fecha y hora

    public Registro(float valor, Date fechaHora) {
        this.valor = valor;
        this.fechaHora = fechaHora;
    }

    public float getValor() {
        return valor;
    }

    public Date getFechaHora() {
        return fechaHora;
    }
}
