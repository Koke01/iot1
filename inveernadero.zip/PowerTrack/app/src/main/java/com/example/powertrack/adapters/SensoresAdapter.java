package com.example.powertrack.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.powertrack.R;
import com.example.powertrack.model.Sensor;
import com.example.powertrack.model.Registro;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.TimeZone;

public class SensoresAdapter extends RecyclerView.Adapter<SensoresAdapter.ViewHolder> {

    private List<Sensor> sensores;

    public SensoresAdapter(List<Sensor> sensores) {
        this.sensores = sensores;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recycler_view_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Sensor sensor = sensores.get(position);

        holder.textViewNombre.setText("Nombre: " + sensor.getNombre());
        holder.textViewModelo.setText("Modelo: " + sensor.getModelo());
        holder.textViewDescripcion.setText("Descripción: " + (sensor.getDescripcion() != null ? sensor.getDescripcion() : "N/A"));
        holder.textViewLecturaActual.setText("Lectura Actual: " + sensor.getLecturaActual());
        holder.textViewUbicacion.setText("Ubicación: " + (sensor.getUbicacion() != null ? sensor.getUbicacion().getNombre() : "No asignada"));
        holder.textViewTipo.setText("Tipo: " + sensor.getTipo());

        // Mostrar la fecha y hora del último registro
        if (sensor.obtenerUltimoRegistro() != null) {
            Registro ultimoRegistro = sensor.obtenerUltimoRegistro();
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

            // Ajuste de zona horaria a Chile (GMT-3)
            sdf.setTimeZone(TimeZone.getTimeZone("America/Santiago"));

            String fechaFormateada = sdf.format(ultimoRegistro.getFechaHora());
            holder.textViewUltimoRegistro.setText("Último Registro: " + fechaFormateada);
        } else {
            holder.textViewUltimoRegistro.setText("Último Registro: No disponible");
        }

    }

    @Override
    public int getItemCount() {
        return sensores.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private TextView textViewNombre;
        private TextView textViewModelo;
        private TextView textViewDescripcion;
        private TextView textViewLecturaActual;
        private TextView textViewUbicacion;
        private TextView textViewTipo;
        private TextView textViewUltimoRegistro;

        public ViewHolder(View view) {
            super(view);
            textViewNombre = view.findViewById(R.id.textViewNombre);
            textViewModelo = view.findViewById(R.id.textViewModelo);
            textViewDescripcion = view.findViewById(R.id.textViewDescripcion);
            textViewLecturaActual = view.findViewById(R.id.textViewLecturaActual);
            textViewUbicacion = view.findViewById(R.id.textViewUbicacion);
            textViewTipo = view.findViewById(R.id.textViewTipo);
            textViewUltimoRegistro = view.findViewById(R.id.textViewUltimoRegistro);
        }
    }
}
