package com.example.powertrack;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Botón para gestionar sensores,
        Button sensoresButton = findViewById(R.id.sensoresButton);
        sensoresButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SensoresActivity.class);
                startActivity(intent);
            }
        });

        // Botón para ver la lista de sensores directamente desde la pantalla main
        Button verSensoresButton = findViewById(R.id.verSensoresButton);
        verSensoresButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListaSensoresActivity.class);
                startActivity(intent);
            }
        });

        // Botón para agregar ubicación,
        Button agregarUbicacionButton = findViewById(R.id.agregarUbicacionButton);
        agregarUbicacionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AgregarUbicacionActivity.class);
                startActivity(intent);
            }
        });
    

