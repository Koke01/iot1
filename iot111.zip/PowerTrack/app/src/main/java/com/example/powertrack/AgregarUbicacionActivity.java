package com.example.powertrack;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.powertrack.datos.Repositorio;
import com.example.powertrack.model.Ubicacion;

public class AgregarUbicacionActivity extends AppCompatActivity {

    private EditText nombreUbicacionEditText;
    private EditText descripcionUbicacionEditText;
    private Button agregarUbicacionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_ubicacion);

        nombreUbicacionEditText = findViewById(R.id.nombreUbicacionEditText);
        descripcionUbicacionEditText = findViewById(R.id.descripcionUbicacionEditText);
        agregarUbicacionButton = findViewById(R.id.agregarUbicacionButton);

        agregarUbicacionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre = nombreUbicacionEditText.getText().toString().trim();
                String descripcion = descripcionUbicacionEditText.getText().toString().trim();

                if (nombre.isEmpty()) {
                    Toast.makeText(AgregarUbicacionActivity.this, "El nombre de la ubicación es obligatorio", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (descripcion.length() > 30) {
                    Toast.makeText(AgregarUbicacionActivity.this, "La descripción no debe exceder los 30 caracteres", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Crear una nueva ubicación y agregarla al repositorio
                Ubicacion nuevaUbicacion = new Ubicacion(nombre, descripcion);
                Repositorio.getInstance().agregarUbicacion(nuevaUbicacion);

                Toast.makeText(AgregarUbicacionActivity.this, "Ubicación agregada exitosamente", Toast.LENGTH_SHORT).show();
                finish(); // Regresa a la actividad anterior
            }
        });
    }
}
